﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PacMan
{
    public partial class PacManForm: Form
    {
        private GameManager gameManager;
        private System.Windows.Forms.Timer gameTimer;

        public PacManForm()
        {
            this.ClientSize = new Size(560, 620);
            this.Text = "Pac-Man";
            this.DoubleBuffered = true;
            this.BackColor = Color.Black;
            this.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            this.StartPosition = FormStartPosition.CenterScreen;

            gameManager = new GameManager(this.ClientSize);
            gameTimer = new System.Windows.Forms.Timer { Interval = 50 };
            gameTimer.Tick += GameLoop;
            gameTimer.Start();

            this.KeyDown += HandleInput;
            this.KeyPreview = true;
        }

        private void GameLoop(object sender, EventArgs e)
        {
            gameManager.Update();
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            gameManager.Draw(e.Graphics);
        }

        private void HandleInput(object sender, KeyEventArgs e)
        {
            gameManager.HandleInput(e);
        }
    }
}
