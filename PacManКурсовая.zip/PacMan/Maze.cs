﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacMan
{
    public class Maze
    {
        public int TileSize { get; } = 20;
        public int Width { get; } = 28;
        public int Height { get; } = 31;

        private int[,] grid;
        private int pelletCount;

        public Maze()
        {
            InitializeGrid();
        }

        private void InitializeGrid()
        {
            grid = new int[Height, Width];
            pelletCount = 0;

            
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    if (y == 0 || y == Height - 1 || x == 0 || x == Width - 1)
                    {
                        grid[y, x] = 1;
                    }
                    else if (y % 2 == 0 && x % 2 == 0)
                    {
                        grid[y, x] = 1;
                    }
                    else
                    {
                        grid[y, x] = 2;
                        pelletCount++;
                    }
                }
            }
            grid[14, 0] = grid[14, Width - 1] = 0;
        }

        public bool IsWall(Point position)
        {
            if (position.X < 0 || position.Y < 0 || position.X >= Width || position.Y >= Height)
                return false; 

            return grid[position.Y, position.X] == 1;
        }

        public bool EatPellet(Point position)
        {
            if (position.X < 0 || position.Y < 0 || position.X >= Width || position.Y >= Height)
                return false;

            if (grid[position.Y, position.X] == 2)
            {
                grid[position.Y, position.X] = 0;
                pelletCount--;
                return true;
            }
            return false;
        }

        public void Draw(Graphics g)
        {
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    var rect = new Rectangle(x * TileSize, y * TileSize, TileSize, TileSize);

                    if (grid[y, x] == 1) 
                    {
                        g.FillRectangle(Brushes.Blue, rect);
                    }
                    else if (grid[y, x] == 2)
                    {
                        g.FillEllipse(Brushes.White,
                            x * TileSize + TileSize / 2 - 2,
                            y * TileSize + TileSize / 2 - 2,
                            4, 4);
                    }
                }
            }
        }
    }
}
