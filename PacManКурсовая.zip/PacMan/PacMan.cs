﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacMan
{
    public class PacMan
    {
        public Point Position { get; private set; }
        public int TileSize { get; }
        public Direction CurrentDirection { get; private set; }
        public Direction NextDirection { get; private set; }
        public int Speed { get; } = 1;

        public PacMan(Point startPosition, int tileSize)
        {
            Position = startPosition;
            TileSize = tileSize;
            CurrentDirection = Direction.None;
            NextDirection = Direction.None;
        }

        public void SetNextDirection(Direction direction)
        {
            NextDirection = direction;
        }

        public void Move(Maze maze)
        {
            
            if (NextDirection != CurrentDirection && CanMove(maze, NextDirection))
            {
                CurrentDirection = NextDirection;
            }

           
            if (CanMove(maze, CurrentDirection))
            {
                switch (CurrentDirection)
                {
                    case Direction.Up:
                        Position = new Point(Position.X, Position.Y - 1);
                        break;
                    case Direction.Down:
                        Position = new Point(Position.X, Position.Y + 1);
                        break;
                    case Direction.Left:
                        Position = new Point(Position.X - 1, Position.Y);
                        break;
                    case Direction.Right:
                        Position = new Point(Position.X + 1, Position.Y);
                        break;
                }
            }

            
            if (Position.X < 0) Position = new Point(maze.Width - 1, Position.Y);
            if (Position.X >= maze.Width) Position = new Point(0, Position.Y);
        }

        private bool CanMove(Maze maze, Direction direction)
        {
            if (direction == Direction.None) return false;

            Point nextPos = Position;

            switch (direction)
            {
                case Direction.Up:
                    nextPos = new Point(Position.X, Position.Y - 1);
                    break;
                case Direction.Down:
                    nextPos = new Point(Position.X, Position.Y + 1);
                    break;
                case Direction.Left:
                    nextPos = new Point(Position.X - 1, Position.Y);
                    break;
                case Direction.Right:
                    nextPos = new Point(Position.X + 1, Position.Y);
                    break;
            }

            return !maze.IsWall(nextPos);
        }

        public void Draw(Graphics g)
        {
            var rect = new Rectangle(Position.X * TileSize, Position.Y * TileSize, TileSize, TileSize);
            g.FillPie(Brushes.Pink, rect, 45, 270);
        }
    }
}
