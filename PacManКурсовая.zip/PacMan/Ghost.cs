﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacMan
{
    public class Ghost
    {
        public Point Position { get; private set; }
        public int TileSize { get; }
        public Color Color { get; }
        public GhostBehavior Behavior { get; }

        private Direction currentDirection;
        private Random random;
        private int speed = 1;

        public Ghost(Point startPosition, int tileSize, Color color, GhostBehavior behavior)
        {
            Position = startPosition;
            TileSize = tileSize;
            Color = color;
            Behavior = behavior;
            random = new Random();
            currentDirection = (Direction)random.Next(0, 4);
        }

        public void Move(Maze maze, Point pacmanPosition)
        {
            
            switch (Behavior)
            {
                case GhostBehavior.Aggressive:
                    ChasePacman(pacmanPosition);
                    break;
                case GhostBehavior.Ambusher:
                    AmbushPacman(pacmanPosition);
                    break;
                case GhostBehavior.Chaser:
                    MoveRandomly();
                    break;
                case GhostBehavior.Random:
                    MoveRandomly();
                    break;
            }

            
            if (CanMove(maze, currentDirection))
            {
                switch (currentDirection)
                {
                    case Direction.Up:
                        Position = new Point(Position.X, Position.Y - 1);
                        break;
                    case Direction.Down:
                        Position = new Point(Position.X, Position.Y + 1);
                        break;
                    case Direction.Left:
                        Position = new Point(Position.X - 1, Position.Y);
                        break;
                    case Direction.Right:
                        Position = new Point(Position.X + 1, Position.Y);
                        break;
                }
            }
            else
            {
               
                currentDirection = (Direction)random.Next(0, 4);
            }

            
            if (Position.X < 0) Position = new Point(maze.Width - 1, Position.Y);
            if (Position.X >= maze.Width) Position = new Point(0, Position.Y);
        }

        private void ChasePacman(Point pacmanPosition)
        {
            if (random.Next(0, 100) < 10) 
            {
                if (Position.X < pacmanPosition.X) currentDirection = Direction.Right;
                else if (Position.X > pacmanPosition.X) currentDirection = Direction.Left;
                else if (Position.Y < pacmanPosition.Y) currentDirection = Direction.Down;
                else currentDirection = Direction.Up;
            }
        }

        private void AmbushPacman(Point pacmanPosition)
        {
            if (random.Next(0, 100) < 10)
            {
               
                currentDirection = (Direction)random.Next(0, 4);
            }
        }

        private void MoveRandomly()
        {
            if (random.Next(0, 100) < 10)
            {
                currentDirection = (Direction)random.Next(0, 4);
            }
        }

        private bool CanMove(Maze maze, Direction direction)
        {
            if (direction == Direction.None) return false;

            Point nextPos = Position;

            switch (direction)
            {
                case Direction.Up:
                    nextPos = new Point(Position.X, Position.Y - 1);
                    break;
                case Direction.Down:
                    nextPos = new Point(Position.X, Position.Y + 1);
                    break;
                case Direction.Left:
                    nextPos = new Point(Position.X - 1, Position.Y);
                    break;
                case Direction.Right:
                    nextPos = new Point(Position.X + 1, Position.Y);
                    break;
            }

            return !maze.IsWall(nextPos);
        }

        public void Draw(Graphics g)
        {
            var rect = new Rectangle(Position.X * TileSize, Position.Y * TileSize, TileSize, TileSize);
            using (var brush = new SolidBrush(Color))
            {
                g.FillRectangle(brush, rect);
            }
        }
    }
}
