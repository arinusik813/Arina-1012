﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacMan
{
    public class GameManager
    {
        private Maze maze;
        private PacMan pacman;
        private Ghost[] ghosts;
        private int score;
        private bool gameOver;
        private Size clientSize;

        public GameManager(Size clientSize)
        {
            this.clientSize = clientSize;
            InitializeGame();
        }

        private void InitializeGame()
        {
            maze = new Maze();
            pacman = new PacMan(new Point(14, 23), maze.TileSize);
            ghosts = new Ghost[4]
            {
                new Ghost(new Point(12, 14), maze.TileSize, Color.Red, GhostBehavior.Aggressive),
                new Ghost(new Point(15, 14), maze.TileSize, Color.Pink, GhostBehavior.Ambusher),
                new Ghost(new Point(12, 17), maze.TileSize, Color.Cyan, GhostBehavior.Random),
                new Ghost(new Point(15, 17), maze.TileSize, Color.Orange, GhostBehavior.Chaser)
            };
            score = 0;
            gameOver = false;
        }

        public void Update()
        {
            if (gameOver) return;

            pacman.Move(maze);

            
            if (maze.EatPellet(pacman.Position))
            {
                score += 10;
            }

            
            foreach (var ghost in ghosts)
            {
                ghost.Move(maze, pacman.Position);

                
                if (ghost.Position == pacman.Position)
                {
                    gameOver = true;
                    MessageBox.Show($"Game Over! Score: {score}","Game Over!");
                    InitializeGame();
                    return;
                }
            }
        }

        public void Draw(Graphics g)
        {
            maze.Draw(g);
            pacman.Draw(g);
            foreach (var ghost in ghosts)
            {
                ghost.Draw(g);
            }

            
            using (var font = new Font("Arial", 12))
            {
                g.DrawString($"Score: {score}", font, Brushes.White, 10, 10);
            }
        }

        public void HandleInput(KeyEventArgs e)
        {
            if (gameOver) return;

            switch (e.KeyCode)
            {
                case Keys.Up:
                    pacman.SetNextDirection(Direction.Up);
                    break;
                case Keys.Down:
                    pacman.SetNextDirection(Direction.Down);
                    break;
                case Keys.Left:
                    pacman.SetNextDirection(Direction.Left);
                    break;
                case Keys.Right:
                    pacman.SetNextDirection(Direction.Right);
                    break;
            }
        }
    }
}
